package com.shsun.calLength;

public interface Stategy {
    public void calLength();
}
