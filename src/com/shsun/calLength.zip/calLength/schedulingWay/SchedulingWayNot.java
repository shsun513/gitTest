package com.shsun.calLength.schedulingWay;

public class SchedulingWayNot implements StategySchedulingWay{
    @Override
    public void calLength() {
        System.out.println("非排班制");
    }
}
