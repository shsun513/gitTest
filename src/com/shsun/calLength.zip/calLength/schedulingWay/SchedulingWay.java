package com.shsun.calLength.schedulingWay;

public class SchedulingWay implements StategySchedulingWay {
    @Override
    public void calLength() {
        System.out.println("排班制");
    }
}
