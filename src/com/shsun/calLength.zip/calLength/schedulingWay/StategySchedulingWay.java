package com.shsun.calLength.schedulingWay;

public interface StategySchedulingWay {
    public void calLength();
}
