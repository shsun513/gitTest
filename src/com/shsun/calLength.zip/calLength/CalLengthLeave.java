package com.shsun.calLength;

public class CalLengthLeave implements Stategy {
    @Override
    public void calLength() {
        System.out.println("请假计算时长");
    }
}
