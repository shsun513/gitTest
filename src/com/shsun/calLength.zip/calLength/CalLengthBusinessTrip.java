package com.shsun.calLength;

public class CalLengthBusinessTrip implements Stategy {
    @Override
    public void calLength() {

    }
}
