package com.shsun.calLength.dateType;

public class DateTypeWorkDay implements StategyDateType {
    @Override
    public void calLength() {
        System.out.println("天计算");
    }
}
