package com.shsun.calLength.dateType;

public interface StategyDateType {
    public void calLength();
}
