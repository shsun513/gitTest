package com.shsun.calLength.dateType;

public class DateTypeWeekend implements StategyDateType {
    @Override
    public void calLength() {
        System.out.println("天计算");
    }
}
