package com.shsun.calLength.unit;

public class UnitDay implements StategyUnit {
    @Override
    public void calLength() {
        System.out.println("天计算");
    }
}
