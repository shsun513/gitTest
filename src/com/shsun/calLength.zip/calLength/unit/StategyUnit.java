package com.shsun.calLength.unit;

public interface StategyUnit {
    public void calLength();
}
