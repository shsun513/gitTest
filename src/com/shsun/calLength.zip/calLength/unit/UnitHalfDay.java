package com.shsun.calLength.unit;

public class UnitHalfDay implements StategyUnit {
    @Override
    public void calLength() {
        System.out.println("半天计算");
    }
}
