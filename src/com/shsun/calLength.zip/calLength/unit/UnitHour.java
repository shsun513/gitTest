package com.shsun.calLength.unit;

public class UnitHour implements StategyUnit {
    @Override
    public void calLength() {
        System.out.println("小时计算");
    }
}
